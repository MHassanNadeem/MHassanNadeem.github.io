Multi-scale Template Matching using C++ and OpenCV

Original Article: http://www.pyimagesearch.com/2015/01/26/multi-scale-template-matching-using-python-opencv/

To compile:
$ make

To run:
./match